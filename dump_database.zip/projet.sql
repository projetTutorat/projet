-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  lun. 04 jan. 2021 à 17:03
-- Version du serveur :  10.4.10-MariaDB
-- Version de PHP :  7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `projet`
--

-- --------------------------------------------------------

--
-- Structure de la table `appartient_etudiant_filiere`
--

DROP TABLE IF EXISTS `appartient_etudiant_filiere`;
CREATE TABLE IF NOT EXISTS `appartient_etudiant_filiere` (
  `num_etu` varchar(50) COLLATE utf8_bin NOT NULL,
  `idFiliere` int(11) NOT NULL,
  PRIMARY KEY (`num_etu`,`idFiliere`),
  KEY `appartient_etudiant_filiere_Filiere_FK` (`idFiliere`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `appartient_etudiant_filiere`
--

INSERT INTO `appartient_etudiant_filiere` (`num_etu`, `idFiliere`) VALUES
('21900001t', 1),
('21900002t', 2),
('21900003t', 3),
('21900004t', 4),
('21900005t', 5),
('21900006t', 6),
('21900007t', 9),
('21900008t', 10),
('21900009t', 11),
('21900010t', 12),
('21900011t', 13),
('21900012t', 14),
('21900013t', 15),
('21900014t', 16),
('21900015t', 17),
('21900016t', 18),
('21900017t', 19),
('21900018t', 20);

-- --------------------------------------------------------

--
-- Structure de la table `calendrier`
--

DROP TABLE IF EXISTS `calendrier`;
CREATE TABLE IF NOT EXISTS `calendrier` (
  `idCalendrier` int(11) NOT NULL AUTO_INCREMENT,
  `annee` varchar(50) COLLATE utf8_bin NOT NULL,
  `mois` varchar(50) COLLATE utf8_bin NOT NULL,
  `jour` varchar(50) COLLATE utf8_bin NOT NULL,
  `heures` varchar(50) COLLATE utf8_bin NOT NULL,
  `minutes` varchar(50) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idCalendrier`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `composee_de_filiere_matiere`
--

DROP TABLE IF EXISTS `composee_de_filiere_matiere`;
CREATE TABLE IF NOT EXISTS `composee_de_filiere_matiere` (
  `idFiliere` int(11) NOT NULL,
  `idMat` int(11) NOT NULL,
  PRIMARY KEY (`idFiliere`,`idMat`),
  KEY `composee_de_filiere_matiere_Matiere_FK` (`idMat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `composee_de_filiere_matiere`
--

INSERT INTO `composee_de_filiere_matiere` (`idFiliere`, `idMat`) VALUES
(1, 1),
(1, 2),
(2, 3),
(2, 4),
(3, 5),
(3, 6),
(4, 7),
(4, 8),
(5, 9),
(5, 10),
(6, 11),
(6, 12),
(9, 13),
(9, 14),
(10, 15),
(10, 16),
(11, 17),
(11, 18),
(12, 19),
(12, 20),
(13, 21),
(13, 22),
(14, 23),
(14, 24),
(15, 25),
(15, 26),
(16, 27),
(16, 28),
(17, 29),
(17, 30),
(18, 31),
(18, 32),
(19, 33),
(19, 34),
(20, 35),
(20, 36);

-- --------------------------------------------------------

--
-- Structure de la table `enseignant`
--

DROP TABLE IF EXISTS `enseignant`;
CREATE TABLE IF NOT EXISTS `enseignant` (
  `num_ens` varchar(50) COLLATE utf8_bin NOT NULL,
  `nomEns` varchar(50) COLLATE utf8_bin NOT NULL,
  `prenomEns` varchar(50) COLLATE utf8_bin NOT NULL,
  `date_naissanceEns` date NOT NULL,
  `mdp` varchar(255) COLLATE utf8_bin NOT NULL,
  `emailEns` varchar(50) COLLATE utf8_bin NOT NULL,
  `num_telEns` varchar(50) COLLATE utf8_bin NOT NULL,
  `idCalendrier` int(11) DEFAULT NULL,
  PRIMARY KEY (`num_ens`),
  KEY `Enseignant_Calendrier_FK` (`idCalendrier`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `enseignant`
--

INSERT INTO `enseignant` (`num_ens`, `nomEns`, `prenomEns`, `date_naissanceEns`, `mdp`, `emailEns`, `num_telEns`, `idCalendrier`) VALUES
('21500001t', 'Turning', 'Jack', '1985-12-06', 'motdepasse', 'jack.turning@univ-tours.fr', '0685865878', NULL),
('21500002t', 'Blackus', 'John', '1984-10-06', 'motdepasse', 'john.blackus@univ-tours.fr', '0685865879', NULL),
('21500003t', 'Radion', 'Tom', '1995-02-06', 'motdepasse', 'tom.radion@univ-tours.fr', '0685865875', NULL),
('21500004t', 'Angur', 'Brad', '1972-02-14', 'motdepasse', 'brad.angur@univ-tours.fr', '0685865876', NULL),
('21500005t', 'Mario', 'Idris', '1982-03-18', 'motdepasse', 'idris.mario@univ-tours.fr', '0685865877', NULL),
('21500006t', 'Olion', 'Helena', '1992-12-18', 'motdepasse', 'helena.olion@univ-tours.fr', '0685865878', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `enseigne_matiere_enseignant`
--

DROP TABLE IF EXISTS `enseigne_matiere_enseignant`;
CREATE TABLE IF NOT EXISTS `enseigne_matiere_enseignant` (
  `idMat` int(11) NOT NULL,
  `num_ens` varchar(50) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idMat`,`num_ens`),
  KEY `enseigne_matiere_enseignant_Enseignant0_FK` (`num_ens`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `enseigne_matiere_enseignant`
--

INSERT INTO `enseigne_matiere_enseignant` (`idMat`, `num_ens`) VALUES
(1, '21500001t'),
(2, '21500001t'),
(3, '21500001t'),
(4, '21500001t'),
(5, '21500001t'),
(6, '21500001t'),
(7, '21500002t'),
(8, '21500002t'),
(9, '21500002t'),
(10, '21500002t'),
(11, '21500002t'),
(12, '21500002t'),
(13, '21500003t'),
(14, '21500003t'),
(15, '21500003t'),
(16, '21500003t'),
(17, '21500003t'),
(18, '21500003t'),
(19, '21500004t'),
(20, '21500004t'),
(21, '21500004t'),
(22, '21500004t'),
(23, '21500004t'),
(24, '21500004t'),
(25, '21500005t'),
(26, '21500005t'),
(27, '21500005t'),
(28, '21500005t'),
(29, '21500005t'),
(30, '21500005t'),
(31, '21500006t'),
(32, '21500006t'),
(33, '21500006t'),
(34, '21500006t'),
(35, '21500006t'),
(36, '21500006t');

-- --------------------------------------------------------

--
-- Structure de la table `enseigne_matiere_tuteur`
--

DROP TABLE IF EXISTS `enseigne_matiere_tuteur`;
CREATE TABLE IF NOT EXISTS `enseigne_matiere_tuteur` (
  `idMat` int(11) NOT NULL,
  `idTuteur` int(11) NOT NULL,
  PRIMARY KEY (`idMat`,`idTuteur`),
  KEY `enseigne_matiere_tuteur_tuteur0_FK` (`idTuteur`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `est_tuteur_etudiant`
--

DROP TABLE IF EXISTS `est_tuteur_etudiant`;
CREATE TABLE IF NOT EXISTS `est_tuteur_etudiant` (
  `idTuteur` int(11) NOT NULL,
  `num_etu` varchar(50) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idTuteur`,`num_etu`),
  KEY `est_tuteur_etudiant_Etudiant0_FK` (`num_etu`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `est_tuteur_etudiant`
--

INSERT INTO `est_tuteur_etudiant` (`idTuteur`, `num_etu`) VALUES
(1, '21900003t'),
(2, '21900009t'),
(3, '21900011t'),
(4, '21900017t'),
(5, '21900001t');

-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

DROP TABLE IF EXISTS `etudiant`;
CREATE TABLE IF NOT EXISTS `etudiant` (
  `num_etu` varchar(50) COLLATE utf8_bin NOT NULL,
  `nom` varchar(50) COLLATE utf8_bin NOT NULL,
  `prenom` varchar(50) COLLATE utf8_bin NOT NULL,
  `date_naissance` date NOT NULL,
  `mdp` varchar(255) COLLATE utf8_bin NOT NULL,
  `email` varchar(50) COLLATE utf8_bin NOT NULL,
  `num_tel` varchar(50) COLLATE utf8_bin NOT NULL,
  `nombreAbsence` int(11) NOT NULL DEFAULT 0,
  `idCalendrier` int(11) DEFAULT NULL,
  PRIMARY KEY (`num_etu`),
  KEY `Etudiant_Calendrier_FK` (`idCalendrier`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `etudiant`
--

INSERT INTO `etudiant` (`num_etu`, `nom`, `prenom`, `date_naissance`, `mdp`, `email`, `num_tel`, `nombreAbsence`, `idCalendrier`) VALUES
('21900001t', 'Deslauriers', 'Bruce', '2000-07-12', 'motdepasse', 'bruce.deslauriers@etu.univ-tours.fr', '0678855601', 0, NULL),
('21900002t', 'Cote', 'Anouk', '2000-07-13', 'motdepasse', 'anouk.cote@etu.univ-tours.fr', '0678855602', 0, NULL),
('21900003t', 'Fanchon', 'Edouard', '2000-07-14', 'motdepasse', 'edouard.fanchon@etu.univ-tours.fr', '0678855603', 0, NULL),
('21900004t', 'Pelchat', 'Jerome', '2000-07-15', 'motdepasse', 'jerome.pelchat@etu.univ-tours.fr', '0678855604', 0, NULL),
('21900005t', 'Melanson', 'Margaux', '2000-07-16', 'motdepasse', 'margaux.melanson@etu.univ-tours.fr', '0678855605', 0, NULL),
('21900006t', 'Provencher', 'Bryon', '2000-07-17', 'motdepasse', 'bryon.provencher@etu.univ-tours.fr', '0678855606', 0, NULL),
('21900007t', 'Boivin', 'Charlotte', '2000-07-19', 'motdepasse', 'charlotte.boivin@etu.univ-tours.fr', '0678855607', 0, NULL),
('21900008t', 'Gaillou', 'Lyle', '2000-07-20', 'motdepasse', 'lyle.gaillou@etu.univ-tours.fr', '0678855608', 0, NULL),
('21900009t', 'Routhier', 'Fabien', '2000-07-21', 'motdepasse', 'fabien.routhier@etu.univ-tours.fr', '0678855609', 0, NULL),
('21900010t', 'Majory', 'Corinne', '2000-07-22', 'motdepasse', 'corinne.majory@etu.univ-tours.fr', '0678855610', 0, NULL),
('21900011t', 'Dupuis', 'Faustin', '2000-07-23', 'motdepasse', 'faustin.dupuis@etu.univ-tours.fr', '0678855611', 0, NULL),
('21900012t', 'Pichette', 'Emile', '2000-07-24', 'motdepasse', 'emile.pichette@etu.univ-tours.fr', '0678855612', 0, NULL),
('21900013t', 'Doust', 'Aline', '2000-07-25', 'motdepasse', 'aline.doust@etu.univ-tours.fr', '0678855613', 0, NULL),
('21900014t', 'Dufour', 'Alain', '2000-07-26', 'motdepasse', 'alain.dufour@etu.univ-tours.fr', '0678855614', 0, NULL),
('21900015t', 'Hughes', 'Gabriel', '2000-07-27', 'motdepasse', 'gabriel.hughes@etu.univ-tours.fr', '0678855615', 0, NULL),
('21900016t', 'Fremont', 'Antoine', '2000-07-28', 'motdepasse', 'antoine.fremont@etu.univ-tours.fr', '0678855616', 0, NULL),
('21900017t', 'Grandbois', 'Audrey', '2000-07-29', 'motdepasse', 'audrey.grandbois@etu.univ-tours.fr', '0678855617', 0, NULL),
('21900018t', 'Caron', 'Theo', '2000-07-30', 'motdepasse', 'theo.caron@etu.univ-tours.fr', '0678855618', 0, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `filiere`
--

DROP TABLE IF EXISTS `filiere`;
CREATE TABLE IF NOT EXISTS `filiere` (
  `idFiliere` int(11) NOT NULL AUTO_INCREMENT,
  `nomFiliere` varchar(50) COLLATE utf8_bin NOT NULL,
  `anneeEtude` int(11) NOT NULL,
  PRIMARY KEY (`idFiliere`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `filiere`
--

INSERT INTO `filiere` (`idFiliere`, `nomFiliere`, `anneeEtude`) VALUES
(1, 'informatique', 1),
(2, 'informatique', 2),
(3, 'informatique', 3),
(4, 'mathematiques', 1),
(5, 'mathematiques', 2),
(6, 'mathematiques', 3),
(9, 'sciences de la vie', 1),
(10, 'sciences de la vie', 2),
(11, 'sciences de la vie', 3),
(12, 'sciences de la terre', 1),
(13, 'sciences de la terre', 2),
(14, 'sciences de la terre', 3),
(15, 'physique', 1),
(16, 'physique', 2),
(17, 'physique', 3),
(18, 'chimie', 1),
(19, 'chimie', 2),
(20, 'chimie', 3);

-- --------------------------------------------------------

--
-- Structure de la table `matiere`
--

DROP TABLE IF EXISTS `matiere`;
CREATE TABLE IF NOT EXISTS `matiere` (
  `idMat` int(11) NOT NULL AUTO_INCREMENT,
  `nomMat` varchar(50) COLLATE utf8_bin NOT NULL,
  `sousCategorie` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idMat`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `matiere`
--

INSERT INTO `matiere` (`idMat`, `nomMat`, `sousCategorie`) VALUES
(1, 'informatique', 'EP 1.1 : Logique pour l’informatique'),
(2, 'informatique', 'EP 1.2 : Programmation fonctionnelle'),
(3, 'informatique', 'EP 2.1 : Programmation objet avancée '),
(4, 'informatique', 'EP 2.2 : Interrogation des bases de données'),
(5, 'informatique', 'EP 3.1 : Théorie des langages et automates'),
(6, 'informatique', 'EP 3.2 : Patrons de conception'),
(7, 'mathematiques', 'EP 1.1 : Calculus'),
(8, 'mathematiques', 'EP 1.2 : Raisonnement'),
(9, 'mathematiques', 'EP 2.1 : Géométrie'),
(10, 'mathematiques', 'EP 2.2 : Arithmétique'),
(11, 'mathematiques', 'EP 3.1 : Calcul différentiel et équations différentielles'),
(12, 'mathematiques', 'EP 3.2 : Algèbre approfondie'),
(13, 'sciences de la vie', 'EP 1.1 : Diversité du monde vivant'),
(14, 'sciences de la vie', 'EP 1.2 : Ecologie-Ethologie'),
(15, 'sciences de la vie', 'EP 2.1 : Physiologie animale'),
(16, 'sciences de la vie', 'EP 2.2 : Biologie cellulaire et signalisation'),
(17, 'sciences de la vie', 'EP 3.1 : Physiologie végétale'),
(18, 'sciences de la vie', 'EP 3.2 : Biologie des organismes'),
(19, 'sciences de la terre', 'EP 1.1 : Observations de terrain et initiation à la cartographie'),
(20, 'sciences de la terre', 'EP 1.2 : Minéralogie et pétrologie'),
(21, 'sciences de la terre', 'EP 2.1 : Physique du Globe'),
(22, 'sciences de la terre', 'EP 2.2 : Géologie structurale'),
(23, 'sciences de la terre', 'EP 3.1 : Géomagnétisme et Géodésie'),
(24, 'sciences de la terre', 'EP 3.2 : Géologie sédimentaire'),
(25, 'physique', 'EP 1.1 : Mécanique du point'),
(26, 'physique', 'EP 1.2 : Électrostatique et électrocinétique'),
(27, 'physique', 'EP 2.1 : Astrophysique ou Électronique analogique'),
(28, 'physique', 'EP 2.2 : Optique'),
(29, 'physique', 'EP 3.1 : Mécanique analytique'),
(30, 'physique', 'EP 3.2 : Ondes mécaniques et hydrodynamiques'),
(31, 'chimie', 'EP 1.1 : Architecture et propriétés des composés inorganiques'),
(32, 'chimie', 'EP 1.2 : Réactivité et transformation en chimie organique'),
(33, 'chimie', 'EP 2.1 : Liaisons chimiques et structures moléculaires'),
(34, 'chimie', 'EP 2.2 : Réactivité des fonctions organiques'),
(35, 'chimie', 'EP 3.1 : Chimie de coordination'),
(36, 'chimie', 'EP 3.2 : Chimie organométallique');

-- --------------------------------------------------------

--
-- Structure de la table `participe_etudiant_seance`
--

DROP TABLE IF EXISTS `participe_etudiant_seance`;
CREATE TABLE IF NOT EXISTS `participe_etudiant_seance` (
  `idSeance` int(11) NOT NULL,
  `num_etu` varchar(50) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idSeance`,`num_etu`),
  KEY `participe_etudiant_seance_Etudiant0_FK` (`num_etu`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `participe_etudiant_seance`
--

INSERT INTO `participe_etudiant_seance` (`idSeance`, `num_etu`) VALUES
(2, '21900004t'),
(3, '21900001t');

-- --------------------------------------------------------

--
-- Structure de la table `salle`
--

DROP TABLE IF EXISTS `salle`;
CREATE TABLE IF NOT EXISTS `salle` (
  `idSalle` int(11) NOT NULL AUTO_INCREMENT,
  `site` varchar(50) COLLATE utf8_bin NOT NULL,
  `batiment` varchar(50) COLLATE utf8_bin NOT NULL,
  `etage` int(11) NOT NULL,
  `numSalle` varchar(50) COLLATE utf8_bin NOT NULL,
  `capaciteMax` int(11) NOT NULL,
  `info` tinyint(1) NOT NULL,
  `tp` tinyint(1) NOT NULL,
  PRIMARY KEY (`idSalle`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `salle`
--

INSERT INTO `salle` (`idSalle`, `site`, `batiment`, `etage`, `numSalle`, `capaciteMax`, `info`, `tp`) VALUES
(2, 'Grandmont', 'E1', 0, '10', 20, 1, 0),
(3, 'Grandmont', 'E1', 0, '20', 20, 1, 0),
(4, 'Grandmont', 'E1', 1, '30', 20, 0, 0),
(5, 'Grandmont', 'E1', 1, '40', 20, 0, 0),
(6, 'Grandmont', 'E1', 2, '50', 20, 0, 1),
(7, 'Grandmont', 'E1', 2, '60', 20, 0, 1),
(8, 'Grandmont', 'E2', 0, '10', 30, 0, 0),
(9, 'Grandmont', 'E2', 0, '20', 30, 0, 0),
(10, 'Grandmont', 'E2', 1, '30', 30, 0, 1),
(11, 'Grandmont', 'E2', 1, '40', 30, 0, 1),
(12, 'Grandmont', 'E2', 2, '50', 30, 0, 1),
(13, 'Grandmont', 'E2', 2, '60', 30, 0, 1),
(14, 'Grandmont', 'F', 0, '21', 400, 0, 0),
(15, 'Grandmont', 'F', 0, '22', 400, 0, 0),
(16, 'Grandmont', 'F', 1, '100', 50, 0, 0),
(17, 'Grandmont', 'F', 1, '120', 50, 0, 0),
(18, 'Grandmont', 'L', 0, '10', 20, 1, 0),
(19, 'Grandmont', 'L', 0, '20', 20, 1, 0),
(20, 'Grandmont', 'L', 1, '30', 20, 1, 0),
(21, 'Grandmont', 'L', 1, '40', 20, 1, 0),
(22, 'Grandmont', 'L', 2, '50', 20, 1, 0),
(23, 'Grandmont', 'L', 2, '60', 20, 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `seance`
--

DROP TABLE IF EXISTS `seance`;
CREATE TABLE IF NOT EXISTS `seance` (
  `idSeance` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `horaire` varchar(255) COLLATE utf8_bin NOT NULL,
  `nbPlaceMax` int(11) NOT NULL,
  `nbPlaceRestante` int(11) NOT NULL,
  `besoin` varchar(255) COLLATE utf8_bin NOT NULL,
  `idSalle` int(11) DEFAULT NULL,
  `idMat` int(11) NOT NULL,
  `num_ens` varchar(50) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idSeance`),
  KEY `Seance_Salle_FK` (`idSalle`),
  KEY `Seance_Matiere0_FK` (`idMat`),
  KEY `Seance_Enseignant1_FK` (`num_ens`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `seance`
--

INSERT INTO `seance` (`idSeance`, `date`, `horaire`, `nbPlaceMax`, `nbPlaceRestante`, `besoin`, `idSalle`, `idMat`, `num_ens`) VALUES
(1, '2020-12-16', '18:00:00', 10, 10, 'Pas de besoin particulier', 2, 1, '21500001t'),
(2, '2020-12-15', '17:00:00', 10, 10, 'Pas de besoin particulier', 2, 7, '21500002t'),
(3, '2020-12-16', '19:00:00', 10, 10, 'Pas de besoin particulier', 2, 1, '21500001t'),
(4, '2020-12-15', '20:00:00', 10, 10, 'Pas de besoin particulier', 4, 7, '21500002t'),
(5, '2020-12-15', '20:00:00', 10, 10, 'Pas de besoin particulier', 4, 7, '21500002t');

-- --------------------------------------------------------

--
-- Structure de la table `se_place_seance_calendrier`
--

DROP TABLE IF EXISTS `se_place_seance_calendrier`;
CREATE TABLE IF NOT EXISTS `se_place_seance_calendrier` (
  `idSeance` int(11) NOT NULL,
  `idCalendrier` int(11) NOT NULL,
  PRIMARY KEY (`idSeance`,`idCalendrier`),
  KEY `se_place_seance_calendrier_Calendrier_FK` (`idCalendrier`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `s_inscrit_tuteur_seance`
--

DROP TABLE IF EXISTS `s_inscrit_tuteur_seance`;
CREATE TABLE IF NOT EXISTS `s_inscrit_tuteur_seance` (
  `idSeance` int(11) NOT NULL,
  `idTuteur` int(11) NOT NULL,
  PRIMARY KEY (`idSeance`,`idTuteur`),
  KEY `s_inscrit_tuteur_seance_Tuteur_FK` (`idTuteur`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `tuteur`
--

DROP TABLE IF EXISTS `tuteur`;
CREATE TABLE IF NOT EXISTS `tuteur` (
  `idTuteur` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idTuteur`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `tuteur`
--

INSERT INTO `tuteur` (`idTuteur`) VALUES
(1),
(2),
(3),
(4);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
